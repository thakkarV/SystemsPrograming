#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define NUMBER_ELEMENTS 128
#define NUMBER_ITEMS 1000000

struct {
  int head;
  int tail;
  int buffer[NUMBER_ELEMENTS];
} circ_buf;


int get_item(void)
{
  int item;
  while(circ_buf.tail == circ_buf.head) { asm volatile("":::"memory");}

  item = circ_buf.buffer[circ_buf.tail];

  asm volatile("":::"memory");
  if((circ_buf.tail + 1) == NUMBER_ELEMENTS) {
    circ_buf.tail = 0;
  }
  else {
    circ_buf.tail++;
  }
  return item;
}

void *reader(void *threadid)
{
  int i;
  for(i = 0; i < NUMBER_ITEMS; i++) {
    if(get_item() != i) {

      printf("Something went wrong with item %d\n", i);
    }
  }

  printf("reader done\n");

  return NULL;
}

void insert_item(int item)
{
  while(circ_buf.tail == ((circ_buf.head + 1) % NUMBER_ELEMENTS)) { asm volatile("":::"memory");}

  circ_buf.buffer[circ_buf.head] = item;

  asm volatile("":::"memory");
  if((circ_buf.head + 1) == NUMBER_ELEMENTS) {
    circ_buf.head = 0;
  }
  else {
    circ_buf.head++;
  }
}

void *writer(void *threadid)
{
  int i;
  for(i = 0; i < NUMBER_ITEMS; i++) {
    insert_item(i);
  }

  printf("writer done\n");

  return NULL;
}


int main(int argc, char *argv[])
{
   pthread_t threads[2];
   int rc;
   long i;

   circ_buf.head = 0;
   circ_buf.tail = 0;

   for(i = 0; i < 2; i++){
     printf("In main: creating thread %ld\n", i);
     rc = pthread_create(&threads[i], NULL, i == 0 ? writer : reader, NULL);

     if(rc) {
       printf("ERROR; return code from pthread_create() is %d\n", rc);
       exit(-1);
     }
   }

   pthread_exit(NULL);
}
