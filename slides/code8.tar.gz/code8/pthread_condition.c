#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include <pthread.h>
#include <unistd.h>

pthread_cond_t cv;
pthread_mutex_t lock;

volatile int foo = 0;

void *thread_main(void *v) {
  while(1) {
    printf("About to lock\n");
    pthread_mutex_lock(&lock);
    while(foo == 0) pthread_cond_wait(&cv, &lock);
    foo = 0;
    printf("About to unlock\n");
    pthread_mutex_unlock(&lock);
  }
  return NULL;
}

int main() {

  pthread_t thread;

  foo = 0;
  pthread_cond_init(&cv, NULL);
  pthread_mutex_init(&lock, NULL);
  pthread_create(&thread, NULL, thread_main, NULL);

  while(1) {
    usleep(3000000);
    pthread_mutex_lock(&lock);
    foo = 1;
    pthread_mutex_unlock(&lock);
    pthread_cond_signal(&cv);
  }

  return 0;
}
