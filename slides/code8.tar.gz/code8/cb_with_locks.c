#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define NUMBER_ELEMENTS 128
#define NUMBER_ITEMS 1000000

struct {
  int head;
  int tail;
  int buffer[NUMBER_ELEMENTS];
  pthread_mutex_t lock;
  pthread_cond_t cond;
} circ_buf;


int get_item(void)
{
  int item;

  pthread_mutex_lock(&circ_buf.lock);

  while(circ_buf.tail == circ_buf.head) {
    pthread_cond_wait(&circ_buf.cond, &circ_buf.lock);
  }

  item = circ_buf.buffer[circ_buf.tail];

  if((circ_buf.tail + 1) == NUMBER_ELEMENTS) {
    circ_buf.tail = 0;
  }
  else {
    circ_buf.tail++;
  }

  pthread_mutex_unlock(&circ_buf.lock);
  pthread_cond_signal(&circ_buf.cond);

  return item;
}

void *reader(void *threadid)
{
  int i;
  for(i = 0; i < NUMBER_ITEMS; i++) {
    if(get_item() != i) {

      printf("Something went wrong with item %d\n", i);
    }
  }

  printf("reader done\n");

  return NULL;
}

void insert_item(int item)
{
  pthread_mutex_lock(&circ_buf.lock);

  while(circ_buf.tail == ((circ_buf.head + 1) % NUMBER_ELEMENTS)) {
    pthread_cond_wait(&circ_buf.cond, &circ_buf.lock);
  }

  circ_buf.buffer[circ_buf.head] = item;

  if((circ_buf.head + 1) == NUMBER_ELEMENTS) {
    circ_buf.head = 0;
  }
  else {
    circ_buf.head++;
  }

  pthread_mutex_unlock(&circ_buf.lock);
  pthread_cond_signal(&circ_buf.cond);
}

void *writer(void *threadid)
{
  int i;
  for(i = 0; i < NUMBER_ITEMS; i++) {
    insert_item(i);
  }

  printf("writer done\n");

  return NULL;
}


int main(int argc, char *argv[])
{
   pthread_t threads[2];
   int rc;
   long i;

   pthread_cond_init(&circ_buf.cond, NULL);
   pthread_mutex_init(&circ_buf.lock, NULL);
   circ_buf.head = 0;
   circ_buf.tail = 0;

   for(i = 0; i < 2; i++){
     printf("In main: creating thread %ld\n", i);
     rc = pthread_create(&threads[i], NULL, i == 0 ? writer : reader, NULL);

     if(rc) {
       printf("ERROR; return code from pthread_create() is %d\n", rc);
       exit(-1);
     }
   }

   pthread_exit(NULL);
}
