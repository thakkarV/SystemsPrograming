#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define NUM_THREADS 5

int global = 0;
pthread_mutex_t lock;

void *increment(void *threadid)
{
  int i = 0;
  for(i = 0; i < 1000000; i++) {
    pthread_mutex_lock(&lock);
    global++;
    pthread_mutex_unlock(&lock);
  }

  pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
   pthread_t threads[NUM_THREADS];
   int rc;
   long i;

   if(pthread_mutex_init(&lock, NULL) != 0) {
     printf("\n mutex init failed\n");
     return 1;
   }

   for(i = 0; i < NUM_THREADS; i++) {
     printf("In main: creating thread %ld\n", i);
     rc = pthread_create(&threads[i], NULL, increment, (void *)i);

     if(rc) {
       printf("ERROR; return code from pthread_create() is %d\n", rc);
       exit(-1);
     }
   }

   for(i = 0; i < NUM_THREADS; i++) {
     pthread_join(threads[i], NULL);
   }

   printf("global = %d\n", global);

   /* Last thing that main() should do */
   pthread_exit(NULL);
}
