#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>

int
main(int argc, char *argv[])
{
  DIR *dir;
  struct dirent *entry;

  if(argc != 2) {
    fprintf(stderr, "usage: %s directory_name\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  printf("Files in \"%s\":\n\n", argv[1]);

  if( (dir = opendir(argv[1])) == NULL) {
    fprintf(stderr, "cannot open %s\n", argv[1]);
    exit(EXIT_FAILURE);
  }

  errno = 0;
  while((entry = readdir(dir)) != NULL) {
    printf("%s\n", entry->d_name);
  }

  if(errno != 0) {
    perror("readdir failed");
  }

  closedir(dir);
  return EXIT_SUCCESS;
}
