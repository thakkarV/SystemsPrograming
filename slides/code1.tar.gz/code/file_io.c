#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define FILE_NAME "foo.txt"
#define WRITE_STR "This is a test"

#define PRINT_FSTAT_INFO(x, code)                                              \
  printf(#x " = %" #code "\n", file_info.st_##x)

int main() {
  char buffer[sizeof(WRITE_STR)];
  ssize_t res;
  off_t lseek_res;
  int close_res;
  int fstat_res;
  struct stat file_info;
  int fd = open(FILE_NAME,  O_RDWR | O_APPEND);

  printf("open(\"" FILE_NAME "\", O_RDWR) returned %d\n", fd);

  if(fd >= 0) {
    fprintf(stderr, "Delete "FILE_NAME" to continue example\n");
    return EXIT_FAILURE;
  }
  else {
    perror("Attempted to open " FILE_NAME);
  }

  fd = open(FILE_NAME, O_RDWR | O_CREAT, S_IRWXU);

  printf("open(\""FILE_NAME"\", O_RDWR | O_CREAT, S_IRWXU) returned %d\n", fd);

  if(fd < 0) {
    perror("Second open failed");
    return EXIT_FAILURE;
  }

  fstat_res = fstat(fd, &file_info);

  if(fstat_res < 0) {
    perror("Failed to fstat file descriptor");
    return EXIT_FAILURE;
  }

  /*
   * struct stat {
   *   dev_t     st_dev;     ID of device containing file
   *   ino_t     st_ino;     inode number
   *   mode_t    st_mode;    protection
   *   nlink_t   st_nlink;   number of hard links
   *   uid_t     st_uid;     user ID of owner
   *   gid_t     st_gid;     group ID of owner
   *   dev_t     st_rdev;    device ID (if special file)
   *   off_t     st_size;    total size, in bytes
   *   blksize_t st_blksize; blocksize for file system I/O
   *   blkcnt_t  st_blocks;  number of 512B blocks allocated
   *   time_t    st_atime;   time of last access
   *   time_t    st_mtime;   time of last modification
   *   time_t    st_ctime;   time of last status change
   * };
   */

  PRINT_FSTAT_INFO(dev, lu);
  PRINT_FSTAT_INFO(ino, lu);
  PRINT_FSTAT_INFO(mode, o);
  PRINT_FSTAT_INFO(nlink, lu);
  PRINT_FSTAT_INFO(uid, u);
  PRINT_FSTAT_INFO(gid, u);
  PRINT_FSTAT_INFO(rdev, lu);
  PRINT_FSTAT_INFO(size, lu);
  PRINT_FSTAT_INFO(blksize, lu);
  PRINT_FSTAT_INFO(blocks, lu);
  PRINT_FSTAT_INFO(atime, lu);
  PRINT_FSTAT_INFO(mtime, lu);
  PRINT_FSTAT_INFO(ctime, lu);

  printf("Sleeping for a little bit\n");

  usleep(6000000);


  res = write(fd, WRITE_STR, sizeof(WRITE_STR) - 1);
  if(res < 0) {
    perror("Failed to write to " FILE_NAME);
    return EXIT_FAILURE;
  }

  printf("Wrote %zd bytes to " FILE_NAME "\n", res);

  lseek_res = lseek(fd, 0, SEEK_SET);

  if(lseek_res == -1) {
    perror("Failed to seek to beginning of file");
    return EXIT_FAILURE;
  }

  res = read(fd, buffer, sizeof(buffer)-1);
  buffer[sizeof(buffer)-1] = 0;

  if(res < 0) {
    perror("Failed to read from file");
    return EXIT_FAILURE;
  }

  printf("Read %zd bytes from file\n", res);
  printf("From file: %s\n", buffer);


  fstat_res = fstat(fd, &file_info);

  if(fstat_res < 0) {
    perror("Filed to fstat file descriptor");
    return EXIT_FAILURE;
  }

  PRINT_FSTAT_INFO(mtime, lu);
  PRINT_FSTAT_INFO(blksize, lu);
  PRINT_FSTAT_INFO(blocks, lu);

  close_res = close(fd);

  if(close_res < 0) {
    perror("Failed to close file " FILE_NAME);
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}
