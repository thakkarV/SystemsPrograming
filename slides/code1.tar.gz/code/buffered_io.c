#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <inttypes.h>


#define FILE_ONE "bar.txt"
#define FILE_TWO "bar2.txt"

uint64_t
get_tsc(void) {
  uint32_t lo, hi;
  asm volatile ("rdtsc" : "=a" (lo), "=d" (hi));
  return (uint64_t)hi << 32 | lo;
}

#define ITERATIONS 1000000

int main()
{
  int i;
  FILE* file = fopen(FILE_ONE, "w");
  int fd = open(FILE_TWO, O_RDWR | O_CREAT, S_IRWXU);
  uint64_t start, middle, end;
  float buffered, unbuffered;

  start = get_tsc();

  for(i = 0; i < ITERATIONS; i++) {
    fprintf(file, "a");
  }

  fflush(file);

  middle = get_tsc();

  for(i = 0; i < ITERATIONS; ++i) {
    write(fd, "a", 1);
  }

  end = get_tsc();

  close(fd);
  fclose(file);

  printf("Buffered:   0x%lX\nUnbuffered: 0x%lX\n",
         middle - start, end - middle);

  buffered = middle - start;
  unbuffered = end - middle;

  printf("ratio buffered/unbuffered: %f\n", buffered / unbuffered);

  return EXIT_SUCCESS;
}
