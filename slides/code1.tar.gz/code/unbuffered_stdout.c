#include <stdio.h>
#include <unistd.h>
#include <string.h>

void myprintf(char *str)
{
  write(STDOUT_FILENO, str, strlen(str));
}

int main()
{
  myprintf("Hello World!");
  sleep(5);
  myprintf("\n");
  sleep(5);

  myprintf("This is the first line\nThis is the second Line");
  sleep(5);

  myprintf("\n");
}
