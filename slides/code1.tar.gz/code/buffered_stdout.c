#include <stdio.h>
#include <unistd.h>

int main()
{
  printf("Hello World!");
  fflush(stdout);
  sleep(5);
  printf("\n");
  fflush(stdout);
  sleep(5);

  printf("This is the first line\nThis is the second Line");
  sleep(5);

  printf("\n");
}
