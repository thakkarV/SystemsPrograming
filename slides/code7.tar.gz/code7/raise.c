#include  <stdio.h>
#include  <signal.h>
#include <stdlib.h>
#include <stdio.h>

long  prev_fact, i;

void sig_handler(int sig)
{
  printf("\nReceived a SIGUSR1.  The answer is %ld! = %ld\n",
         i-1, prev_fact);
  exit(0);
}

int main(void)
{
  long fact;

  printf("Factorial Computation:\n\n");
  signal(SIGUSR1, sig_handler);
  for (prev_fact = i = 1; ; i++, prev_fact = fact) {
    fact = prev_fact * i;
    if (fact < 0) {
      printf("fact = %ld\n", fact);
      raise(SIGUSR1);
    }
    else {
      printf("     %ld! = %ld\n", i, fact);
    }
  }
}
