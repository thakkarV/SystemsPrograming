#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>


void sig_handler(int sig)
{
  printf("Recieved SIGINT and ignoring it\n");
  return;
}

int main(void)
{

  signal(SIGINT, sig_handler);
  while(1) {
    printf("In Loop\n");
    usleep(9000000);
  }
}
