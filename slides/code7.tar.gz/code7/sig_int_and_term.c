#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>


void sig_handler(int sig)
{
  printf("Recieved signal and ignoring it %d\n", sig);
  return;
}

int main(void)
{

  signal(SIGINT, sig_handler);
  signal(SIGTERM, sig_handler);
  signal(SIGKILL, sig_handler);
  while(1) {
    printf("In Loop\n");
    usleep(9000000);
  }
}
