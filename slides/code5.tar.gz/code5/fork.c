#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
  printf("Start: %d\n", getpid());

  if(fork()) {
    printf("In parent :%d\n", getpid());
  }
  else {
    printf("In child %d\n", getpid());
    /* execlp("echo", "echo", "hello", "world", NULL); */
    /* fprintf(stderr, "Failed to exec echo\n"); */
  }

  return 0;
}
