#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>


#define FORK_FUNC vfork
#define stringify(x) #x

int main()
{
  volatile int value = 5;
  pid_t result;

  if((result = FORK_FUNC())) {
    if(result == -1) {
      perror(stringify(FORK_FUNC) " failed");
    }
    else {
      value++;
      printf("In parent: value = %d\n", value);
    }
  }
  else {
    value++;
    printf("In child: value = %d\n", value);
  }
  _exit(0);
}
