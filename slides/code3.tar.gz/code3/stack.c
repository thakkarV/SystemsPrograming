#include <stdio.h>
#include <stdlib.h>

#define STACK_SIZE (0x1000-0x20)
#define RECURSE_LEVEL 20

void recursive(uint i) {
  char local_variable[STACK_SIZE];
  printf("%*d: &local_variable = %p\n", 2, i, &local_variable);
  if(i < RECURSE_LEVEL) {
    recursive(i+1);
  }
}


int main()
{
  recursive(0);

  return EXIT_SUCCESS;
}
