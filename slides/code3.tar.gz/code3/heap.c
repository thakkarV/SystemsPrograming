#include <stdlib.h>
#include <stdio.h>

#define MALLOC_SIZE 0x1000
#define ITERATIONS 100000
#define PRINT_ITERATIONS 10000

int main()
{
  int i;
  for(i = 0; i < ITERATIONS; i++) {
    void* tmp = malloc(MALLOC_SIZE);

    if((i % PRINT_ITERATIONS) == 0) {
      printf("%*d: malloc returned %p\n", 5, i, tmp);
    }
  }

  return EXIT_SUCCESS;
}
