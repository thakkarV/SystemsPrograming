#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void function()
{
  fprintf(stderr, "%s\n", __FUNCTION__);
}

void function2()
{
  fprintf(stderr, "%s\n", __FUNCTION__);
}

void function3()
{
  fprintf(stderr, "%s\n", __FUNCTION__);
}

int main(int argc, char* argv[])
{
  printf("AAA");
  atexit(function);
  atexit(function2);
  atexit(function3);

  if(argc == 2 && (strcmp(argv[1], "0") == 0)) {
    exit(EXIT_SUCCESS);
  }
  else {
    _Exit(EXIT_SUCCESS);
  }
}
