#include <setjmp.h>
#include <stdlib.h>
#include <stdio.h>

static jmp_buf jbuf;

//#define X_MODIFIER volatile
#define X_MODIFIER register

void baz(void) {
  longjmp(jbuf, 1);
}

void bar(int x)
{
  printf("in bar(): x = %d\n", x);
  baz();
}

void foo(void)
{
  int x = 10;
  if(setjmp(jbuf) != 0) {
    printf("After longjump: x = %d\n", x);
    exit(0);
  }

  x = 20;
  bar(x);
}

int main()
{
  foo();
  return 0;
}
