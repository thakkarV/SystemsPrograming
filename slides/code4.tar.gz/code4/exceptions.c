#include <setjmp.h>
#include <stdio.h>
#include <stdlib.h>
#include "my_exceptions.h"

int
main(int argc, char** argv)
{
   TRY
   {
      printf("In Try Statement\n");
      THROW( 1 );
      printf("I do not appear\n");
   }
   CATCH( 1 )
   {
      printf("Got 1!\n");
   }
   CATCH( 2 )
   {
      printf("Got 2!\n");
   }
   CATCH( 3 )
   {
      printf("Got 3!\n");
   }
   FINALLY
   {
      printf("...et in arcadia Ego\n");
   }
   ETRY;

   return 0;
}

