#define _GNU_SOURCE
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

// int getresuid(uid_t *ruid, uid_t *euid, uid_t *suid);

void print_uids(void)
{
  uid_t ruid, euid, suid;

  getresuid(&ruid, &euid, &suid);
  printf("ruid = %u, euid = %u, suid = %u\n",
         ruid, euid, suid);
}

void mysetuid(uid_t id)
{
  setuid(id) == 0 ?
    printf("setuid(%u) successful\n", id) :
    printf("setuid(%u) failed\n", id);
}

void myseteuid(uid_t id)
{
  seteuid(id) == 0 ?
    printf("seteuid(%u) successful\n", id) :
    printf("seteuid(%u) failed\n", id);
}

int main()
{
  print_uids();
  myseteuid(1000);
  print_uids();
  myseteuid(0);
  print_uids();

  return EXIT_SUCCESS;
}
