#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

FILE *mypopen(const char *command, const char *type)
{
  int writing;
  int fds[2];

  if(strcmp(type, "w") == 0) {
    writing = 1;
  }
  else if(strcmp(type, "r") == 0) {
    writing = 0;
  }
  else {
    return NULL;
  }

  pipe(fds);
  if(fork()) {
    FILE* result;
    // In the parent
    if(writing) {
      result = fdopen(fds[1], "w");
      close(fds[0]);
    }
    else {
      result = fdopen(fds[0], "r");
      close(fds[1]);
    }
    return result;
  }
  else {
    // In child
    if(writing) {
      dup2(fds[0], 0);
    }
    else {
      dup2(fds[1], 1);
    }
    close(fds[0]);
    close(fds[1]);
    execl("/bin/sh", "/bin/sh", "-c", command, NULL);
    exit(1);
  }
}

int mypclose(FILE* stream)
{
  return 0;
}

#if 1
#  define POPEN mypopen
#  define PCLOSE mypclose
#else
#  define POPEN popen
#  define PCLOSE pclose
#endif

#define LINE_BUFFER_SIZE 512

int main()
{
  char line[LINE_BUFFER_SIZE];
  FILE* fp = POPEN("cat < temp.txt", "r");

  if(fp == NULL) {
    fprintf(stderr, "Error fp = NULL\n");
    return EXIT_FAILURE;
  }

  while(fgets(line, LINE_BUFFER_SIZE, fp) != NULL) {
    printf("%s", line);
  }

  PCLOSE(fp);

  return 0;
}
