#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main()
{

  if(fork()) {
    printf("In parent");
  }
  else {

    int foo_fd = open("foo.txt", O_WRONLY | O_CREAT, S_IRWXU);

    dup2(foo_fd, 1);
    close(foo_fd);

    execlp("ls", "ls", NULL);
    printf("Only if an error occurs\n");

  }

  return 0;
}
