#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
  int newFD = dup(1);

  printf("newFD = %d\n", newFD);

  write(newFD, "hello world\n",
        sizeof("hello world\n") - 1);

  return 0;
}
